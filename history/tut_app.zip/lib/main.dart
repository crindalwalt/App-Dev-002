import 'package:flutter/material.dart';
import 'package:flutter_basic_training/root/tut_app.dart';

void main() {
  runApp(
    TutApp(),
  );
}
